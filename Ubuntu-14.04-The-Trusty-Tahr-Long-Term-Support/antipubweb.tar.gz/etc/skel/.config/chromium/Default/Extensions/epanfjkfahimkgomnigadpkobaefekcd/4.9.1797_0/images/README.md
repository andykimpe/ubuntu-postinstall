This folder is for all toolbar icons, browser chrome, etc.

Images used within application body should be kept in pages/images.

