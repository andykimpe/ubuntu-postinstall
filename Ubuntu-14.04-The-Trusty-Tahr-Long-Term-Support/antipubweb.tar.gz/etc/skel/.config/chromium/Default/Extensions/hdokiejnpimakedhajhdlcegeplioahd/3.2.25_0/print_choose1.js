function doprint(a){a?getBG().g_hidenotes&&(document.getElementById("notes").style.display="none"):get_data("print_choose",function(){doprint(!0)})};
