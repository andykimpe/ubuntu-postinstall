# Images

This folder is for application UI images.

All toolbar icons, and elements of browser chrome should be kept in the top level images folder.

